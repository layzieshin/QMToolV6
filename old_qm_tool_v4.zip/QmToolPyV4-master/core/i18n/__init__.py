from .locale_settings import SETTINGS_SCHEMA   # re-export
