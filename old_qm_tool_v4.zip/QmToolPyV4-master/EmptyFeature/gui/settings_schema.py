SETTINGS_SCHEMA = [
    {
        "key": "auto_version",
        "label": "Auto versioning",
        "type": "bool",
        "default": True,
        "scope": "global",   # oder "user" / "both"
    },
]