MODULE_ROLES = [
    "Creator",
    "Editor",
    "Publisher",
]